<?php
// Redirect Access Account to the real login page
header("Location: ../auth/login.php");
exit;