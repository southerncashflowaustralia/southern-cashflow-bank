<div class="sidebar">
    <h2>Southern Cashflow Finance</h2>

    <a href="dashboard.php">Dashboard</a>
    <a href="deposit.php">Deposit</a>
    <a href="withdraw.php">Withdraw</a>
    <a href="transfer.php">Transfer</a>
    <a href="loans.php">Loans & Interest</a>
    <a href="profile.php">Profile</a>
    <a href="statements.php">Statements</a>
    <a href="billpay.php">Bill Pay</a>
    <a href="cards.php">Cards</a>
    <a href="investments.php">Investments</a>
    <a href="settings.php">Settings</a>

    <a href="../auth/logout.php" style="margin-top:auto; background:#8b0000;">
        Logout
    </a>
</div>