<?php
echo "Test page works!";